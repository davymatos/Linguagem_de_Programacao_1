#include <stdio.h>
int main(void)
{
 int I;
 for (I = 1; I <= 10; I += 2)
 printf("I = %2d\n", I);
 return 0;
} 