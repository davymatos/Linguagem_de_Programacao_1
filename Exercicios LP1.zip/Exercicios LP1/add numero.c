#include <stdio.h>
int main(void)
{
 int A;
 int B;
 int X;
 scanf("%d", &A);
 scanf("%d", &B);
 X = A + B;
 printf("%d", X);
 return 0;
}
